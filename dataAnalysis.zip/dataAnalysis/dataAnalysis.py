
# 출처 : https://doorbw.tistory.com/173?category=706990(함수 정리)
import pandas as pd #데이터를 정렬할 수 있는 분석 라이브러리 
import numpy as np #벡터 및 행렬 연산 등 고성능 수치 계산을 위함
import matplotlib.pyplot as plt
#매트랩과 비슷한 형태 자료구조를 쉽게 시작화 
import seaborn as sns


raw_data = pd.read_excel('titanic.xls')
raw_data.info()  #----------------------------데이터 정보 출력 


raw_data.describe() #생성했던 DataFrame의 간단한 통계정보를 제시 
#count(데이터 개수) / 평균값(mean) / 표준편차(std) / 최솟값 (min) / 4분위수(25%, 50%, 75%) / 최댓값(max)
#----------------------데이터 표로 시각화 출력


f, ax = plt.subplots(1,2,figsize = (15,10))
raw_data['survived'].value_counts().plot.pie(explode = [0, 0.1], autopct = '%1.2f%%', ax = ax[0])
ax[0].set_title('Survived')
ax[0].set_ylabel('')

sns.countplot('survived', data = raw_data, ax = ax[1])
ax[1].set_title('Servived')
plt.show()
#-------------------------------------------데이터 생존그래프 출력 


raw_data['age'].hist(bins = 20, figsize = (20,10), grid = False)
#--------------------------------------탑승 인원 나이를 표로 출력 

raw_data.groupby('sex').mean() 
#------------------------------- 성에 따른 생존율 

f, ax = plt.subplots(figsize = (12,6))
#미생존
g = sns.kdeplot(raw_data["age"][(raw_data["survived"] == 0) & (raw_data["age"].notnull())],
                ax = ax, color = "Blue", shade = True)
#생존 
g = sns.kdeplot(raw_data["age"][(raw_data["survived"] == 1) & (raw_data["age"].notnull())],
                ax = g, color = "Green", shade = True)

g.set_xlabel("Age") #x축
g.set_ylabel("Frequency") #y축
g = g.legend(["Not Survived", "Survived"]) #오른쪽 상단 

#------------------------------------------나이에 따른 생존을 그래프로 표시 
                                